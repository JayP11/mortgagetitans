import React, { useEffect } from "react";
import "./ContactUs.css";
import { Helmet } from "react-helmet";

const ContactUs = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <>
      <Helmet>
        <title>Mortgage Titans | Contacts</title>
      </Helmet>
      <section className="contact_sec">
        <div className="contact">
          <div className="c-form">
            <h1 className="contact-us-heading"> Contact Us</h1>
            <form className="c-form">
              <lable className="c-lbl">Name</lable>
              <input
                type="text"
                placeholder=""
                // value={name}
                className="c-txt"
                // onChange={(e) => setname(e.target.value)}
              />
              {/* <input type="text" className="c-txt" /> */}
              <lable className="c-lbl">Number</lable>
              <input
                type="text"
                placeholder=""
                name="field-name"
                // value={number}
                maxLength={10}
                // onChange={(e) => {
                //   if (mobileValidate(e.target.value)) {
                //     setnumber(e.target.value);
                //   }
                // }}
                className="c-txt"
              />
              {/* <input type="text" className="c-txt" /> */}
              <lable className="c-lbl">Email</lable>
              <input
                type="text"
                placeholder=""
                // value={email}
                // onChange={(e) => setemail(e.target.value)}
                className="c-txt"
              />

              <lable className="c-lbl">Subject</lable>
              <input
                type="text"
                placeholder=""
                // value={subject}
                // onChange={(e) => setsubject(e.target.value)}
                className="c-txt"
              />
              {/* <input type="text" className="c-txt" /> */}
              <lable className="c-lbl">Descreption</lable>
              <textarea
                placeholder="Please leave comment here..."
                // value={description}
                className="c-msg-txt"
                // onChange={(e) => setdescription(e.target.value)}
              ></textarea>
              {/* <textarea type="text" className="c-msg-txt" /> */}
              <a
                href="javascript:void(0)"
                className="c-form-btn"
                // onClick={() => kContactus()}
              >
                Submit
              </a>
            </form>
          </div>
          <div className="c-details">
            <h2 className="quick-heading">Quick Contact</h2>
            <div className="con-info-flex">
              {/* <HiOutlineMail className="con-info-icon" /> */}
              <p className="c-ulbl mt01">Email Id :</p>
            </div>

            <p className="c-dlbl">jash.shah@mortgagetitans.com.au</p>
            <div className="con-info-flex">
              {/* <AiOutlinePhone className="con-info-icon" /> */}
              <p className="c-ulbl">Phone :</p>
            </div>
            <p className="c-dlbl">0410 222 182</p>
            {/* <div className="con-info-flex">
              <GrLocation className="con-info-icon" />
              <p className="c-ulbl">Address :</p>
            </div>
            <p className="c-dlbl" style={{ marginBottom: "1.5rem" }}>
              Applified, 301 Pride Square JK Chowk Rajkot 360005
            </p>

            <iframe
              width="100%"
              height="300"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d118147.80351149273!2d70.82129635!3d22.27348695!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3959c98ac71cdf0f%3A0x76dd15cfbe93ad3b!2sRajkot%2C%20Gujarat!5e0!3m2!1sen!2sin!4v1714548244437!5m2!1sen!2sin"
              frameborder="0"
              scrolling="no"
              marginheight="0"
              marginwidth="0"
              allowFullScreen
            ></iframe> */}

            <br />
          </div>
        </div>
      </section>
    </>
  );
};

export default ContactUs;
