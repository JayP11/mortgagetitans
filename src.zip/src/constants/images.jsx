import logo from "../assets/logo.png";
import profile_img from "../assets/profile_img.jpeg";
import homehero from "../assets/homehero.webp";
import gif from "../assets/gif.png";
import approve_loan_img_icon from "../assets/approved.png";
import debt_img_img from "../assets/debt.png";
import buy_home_icon from "../assets/buy.png";
import consectetur_img_icon from "../assets/budget.png";
import investment_img_icon from "../assets/investment.png";
import mortgage__img_icon from "../assets/mortgage.png";
import constructionlon_img from "../assets/constructionlon_img.png";
import firsttimehome_img from "../assets/firsttimehome_img.jpg";
import debtconsolidationloans_img from "../assets/debtconsolidationloans_img.jpg";
import home_lone from "../assets/home_lone.jpg";
import investmentloan2_img from "../assets/investmentloan2_img.jpg";
import preapprovedloan_img from "../assets/preapprovedloan_img.png";
import faqImg from "../assets/faqImg.png";
import service_bgimg from "../assets/services_bg.jpeg";

export default {
  logo,
  profile_img,
  homehero,
  gif,
  approve_loan_img_icon,
  debt_img_img,
  buy_home_icon,
  consectetur_img_icon,
  investment_img_icon,
  mortgage__img_icon,
  constructionlon_img,
  firsttimehome_img,
  debtconsolidationloans_img,
  home_lone,
  investmentloan2_img,
  preapprovedloan_img,
  faqImg,
  service_bgimg,
};
