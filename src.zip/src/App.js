import { BrowserRouter, Route, Routes } from "react-router-dom";
import "./App.css";
import Navbar from "./common/navbar/Navbar";
import Homepage from "./pages/homepage/Homepage";
import Footer from "./common/footer/Footer";
import AboutPage from "./pages/aboutPage/AboutPage";
import ContactUs from "./pages/contactus/ContactUs";
import Services from "./pages/services/Services";

function App() {
  return (
    <>
      <BrowserRouter>
        <Navbar />
        <Routes>
          <Route path="/" element={<Homepage />}></Route>
          <Route path="/AboutPage" element={<AboutPage />}></Route>
          <Route path="/ContactUs" element={<ContactUs />}></Route>
          <Route path="/Services" element={<Services />}></Route>
        </Routes>
        <Footer />
      </BrowserRouter>
    </>
  );
}

export default App;
