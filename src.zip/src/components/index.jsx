import HomeHero from "./homeHero/HomeHero";
import Testimonials from "./testimonials/Testimonials";
import ServicesHome from "./servicesHome/ServicesHome";
import HomeBio from "./homeBio/HomeBio";
import AboutHero from "./aboutHero/AboutHero";
import Faq from "./faq/Faq";

export { HomeHero, Testimonials, ServicesHome, HomeBio, AboutHero, Faq };
